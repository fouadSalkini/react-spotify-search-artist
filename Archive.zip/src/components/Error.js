import React from 'react';

const Error = () => {
  return (
    <div>
      <p>Error: Path does not exist!!!11!!1</p>
    </div>
  );
};

export default Error;