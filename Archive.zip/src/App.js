import React, { Component } from 'react';

import Root from './components/Root';

class App extends Component {


	



	render() {
		return (
		        <div>
		          <Root />
		        </div>
		);
	}
}


export default App;

